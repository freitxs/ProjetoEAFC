<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST["nome"];
    $imagemNome = $_FILES["imagem"]["name"];
    $imagemTmp = $_FILES["imagem"]["tmp_name"];
    $destino = "imagens/" . uniqid() . "_" . basename($imagemNome);

    if (move_uploaded_file($imagemTmp, $destino)) {
        echo "Jogador '$nome' cadastrado com sucesso!<br>";
        echo "<img src='$destino' width='200'>";
    } else {
        echo "Erro ao enviar imagem.";
    }
}
?>