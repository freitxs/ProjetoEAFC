
<?php
session_start();

// Caminho do arquivo de dados
$caminho_cartas = __DIR__ . '/dados/cartas.php';

// Se não existir, cria array vazio
$cartas = file_exists($caminho_cartas) ? include $caminho_cartas : [];

// Processar os dados do formulário
$nome = $_POST['nome'] ?? '';
$nacionalidade = $_POST['nacionalidade'] ?? '';
$categoria = $_POST['categoria'] ?? '';
$descricao = $_POST['descricao'] ?? '';

// Lidar com imagem
$imagem_nome = '';
if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
    $imagem_tmp = $_FILES['imagem']['tmp_name'];
    $imagem_nome = basename($_FILES['imagem']['name']);
    move_uploaded_file($imagem_tmp, __DIR__ . "/imagens/" . $imagem_nome);
}

// Criar nova carta
$novaCarta = [
    'id' => count($cartas) + 1,
    'nome' => $nome,
    'nacionalidade' => $nacionalidade,
    'categoria' => $categoria,
    'descricao' => $descricao,
    'imagem' => $imagem_nome,
    'stats' => []
];

// Adicionar e salvar
$cartas[] = $novaCarta;
file_put_contents($caminho_cartas, "<?php\nreturn " . var_export($cartas, true) . ";");

// Redireciona para a página principal
header("Location: index.php");
exit;
?>
