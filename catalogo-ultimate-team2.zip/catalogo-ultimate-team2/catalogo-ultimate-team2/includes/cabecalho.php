<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    $usuarioFixo = 'admin';
    $senhaCorreta = '1234';

    if ($usuario === $usuarioFixo && $senha === $senhaCorreta) {
        $_SESSION['logado'] = true;
        header('Location: index.php'); // Evita reenvio do formulário
        exit;
    } else {
        $erro = 'Usuário ou senha inválidos.';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Catalogo UT</title>
    <style>
        body { margin: 0; text-align: center; font-family: Arial; }
        nav {
            background-color: #333;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        nav .logo {
            font-size: 20px;
            font-weight: bold;
        }
        nav .login-area form {
            display: flex;
            gap: 5px;
        }
        nav input {
            padding: 5px;
        }
        nav button {
            padding: 5px 10px;
            cursor: pointer;
        }
        .erro {
            color: red;
            margin-left: 10px;
            padding: 10px;
        }
        .botao {
    padding: 8px 16px;
    background-color: #00c851; /* verde neon escuro */
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.botao:hover {
    background-color: #007e33; /* verde mais escuro no hover */
    transform: scale(1.05);
}
.filtro-form {
    margin: 20px auto;
    max-width: 800px;
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
    justify-content: center;
}

.filtro-form input[type="text"] {
    padding: 8px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 14px;
}

.filtro-form .botao {
    background-color: #00cc66;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
}

.filtro-form .botao:hover {
    background-color: #00b359;
}
.tabela-stats {
    max-width: 600px;
    margin: 20px auto;
}

.tabela-stats table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.tabela-stats td {
    border: 1px solid #ccc;
    padding: 8px 12px;
}

.tabela-stats h4 {
    background-color: #00cc66;
    color: white;
    padding: 8px;
    border-radius: 5px;
}


    </style>
</head>
<body>

<nav>
    <div class="logo">Catálogo EA FC 25 Ultimate Team</div>

    <div class="login-area">
        <?php if (isset($_SESSION['logado']) && $_SESSION['logado']): ?>
            <span>Olá, admin</span>

            <a href="protegido.php">
            <button type="button" class="botao">Adicionar nova carta</button>
            </a>

            <form method="post" action="logout.php" style="display:inline;">
            <button type="submit" class="botao">Sair</button>
            </form>
        <?php else: ?>
            <form method="post">
                <input type="text" name="usuario" placeholder="Usuário" required>
                <input type="password" name="senha" placeholder="Senha" required>
                <button type="submit" name="login" class="botao">Entrar</button>
            </form>
        <?php endif; ?>
    </div>
</nav>

<?php if ($erro && isset($_POST['login'])): ?>
    <div class="erro"><?= $erro ?></div>
<?php endif; ?>
