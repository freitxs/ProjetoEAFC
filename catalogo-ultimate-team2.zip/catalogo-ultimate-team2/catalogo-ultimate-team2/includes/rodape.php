</main>
<footer>
    <p>&copy; 2025 - Lucas & João Henrique</p>
</footer>
</body>
</html>