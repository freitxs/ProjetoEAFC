<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Itens padrões + novos da sessão
$cartasFixas = [
    [
        "id" => 1,
        "nome" => "Erling Haaland",
        "nacionalidade" => "Noruega",
        "categoria" => "Atacante",
        "imagem" => "imagens/Haaland.png",
        "descricao" => "Atacante norueguês do Manchester City com finalização absurda.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 80,
        "Pique" => 94
    ],
    "Finalização" => [
        "Posicionamento" => 96,
        "Finalização" => 96,
        "Força do Chute" => 94,
        "Chutes de Longe" => 83,
        "Voleios" => 90,
        "Pênaltis" => 90
    ],
    "Passe" => [
        "Visão" => 74,
        "Cruzamento" => 58,
        "Precisão de Falta" => 62,
        "Passe Curto" => 77,
        "Passe Longo" => 66,
        "Efeito" => 77
    ],
    "Drible" => [
        "Agilidade" => 77,
        "Equilíbrio" => 69,
        "Reações" => 94,
        "Controle de Bola" => 83,
        "Drible" => 79,
        "Compostura" => 87
    ],
    "Defesa" => [
        "Intercepções" => 43,
        "Cabeceio" => 83,
        "Consciência Defensiva" => 38,
        "Desarme em Pé" => 47,
        "Carrinho" => 29
    ],
    "Físico" => [
        "Impulsão" => 92,
        "Fôlego" => 76,
        "Força" => 93,
        "Agressividade" => 88
    ]
]
    ],
    [
        "id" => 2,
        "nome" => "Kevin De Bruyne",
        "nacionalidade" => "Bélgica",
        "categoria" => "Meio-Campo",
        "imagem" => "imagens/DeBruyne.png",
        "descricao" => "Meia belga com excelente visão de jogo e passes milimétricos.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 67,
        "Pique" => 67
    ],
    "Finalização" => [
        "Posicionamento" => 88,
        "Finalização" => 84,
        "Força do Chute" => 92,
        "Chutes de Longe" => 90,
        "Voleios" => 83,
        "Pênaltis" => 83
    ],
    "Passe" => [
        "Visão" => 95,
        "Cruzamento" => 95,
        "Precisão de Falta" => 83,
        "Passe Curto" => 94,
        "Passe Longo" => 93,
        "Efeito" => 93
    ],
    "Drible" => [
        "Agilidade" => 75,
        "Equilíbrio" => 78,
        "Reações" => 92,
        "Controle de Bola" => 92,
        "Drible" => 86,
        "Compostura" => 88
    ],
    "Defesa" => [
        "Intercepções" => 66,
        "Cabeceio" => 55,
        "Consciência Defensiva" => 66,
        "Desarme em Pé" => 70,
        "Carrinho" => 53
    ],
    "Físico" => [
        "Impulsão" => 71,
        "Fôlego" => 88,
        "Força" => 75,
        "Agressividade" => 75
    ]
]
    ],
    [
        "id" => 3,
        "nome" => "Vinícius Jr",
        "nacionalidade" => "Brasil",
        "categoria" => "Atacante",
        "imagem" => "imagens/Vinicius.png",
        "descricao" => "Ponta brasileiro do Real Madrid, conhecido por sua velocidade e dribles.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 95,
        "Pique" => 95
    ],
    "Finalização" => [
        "Posicionamento" => 87,
        "Finalização" => 89,
        "Força do Chute" => 81,
        "Chutes de Longe" => 83,
        "Voleios" => 73,
        "Pênaltis" => 71
    ],
    "Passe" => [
        "Visão" => 85,
        "Cruzamento" => 81,
        "Precisão de Falta" => 62,
        "Passe Curto" => 83,
        "Passe Longo" => 77,
        "Efeito" => 79
    ],
    "Drible" => [
        "Agilidade" => 94,
        "Equilíbrio" => 84,
        "Reações" => 86,
        "Controle de Bola" => 90,
        "Drible" => 93,
        "Compostura" => 83
    ],
    "Defesa" => [
        "Intercepções" => 26,
        "Cabeceio" => 50,
        "Consciência Defensiva" => 32,
        "Desarme em Pé" => 25,
        "Carrinho" => 18
    ],
    "Físico" => [
        "Impulsão" => 74,
        "Fôlego" => 84,
        "Força" => 65,
        "Agressividade" => 58
    ]
]
    ],
    [
        "id" => 4,
        "nome" => "Mbappé",
        "nacionalidade" => "França",
        "categoria" => "Atacante",
        "imagem" => "imagens/mbappe.png",
        "descricao" => "Atacante francês extremamente rápido e habilidoso, destaque no PSG e na Seleção Francesa.",
        "stats" => [
            "Ritmo" => [
                "Aceleração" => 97,
                "Pique" => 97
            ],
            "Finalização" => [
                "Posicionamento" => 93,
                "Finalização" => 94,
                "Força do Chute" => 90,
                "Chutes de Longe" => 83,
                "Voleios" => 84,
                "Pênaltis" => 84
            ],
            "Passe" => [
                "Visão" => 83,
                "Cruzamento" => 78,
                "Precisão de Falta" => 69,
                "Passe Curto" => 86,
                "Passe Longo" => 71,
                "Efeito" => 80
            ],
            "Drible" => [
                "Agilidade" => 93,
                "Equilíbrio" => 82,
                "Reações" => 93,
                "Controle de Bola" => 92,
                "Drible" => 93,
                "Compostura" => 88
            ],
            "Defesa" => [
                "Intercepções" => 38,
                "Cabeceio" => 73,
                "Consciência Defensiva" => 26,
                "Desarme em Pé" => 34,
                "Carrinho" => 32
            ],
            "Físico" => [
                "Impulsão" => 88,
                "Fôlego" => 88,
                "Força" => 77,
                "Agressividade" => 64
            ]
        ]
    
    ],
    [
        "id" => 5,
        "nome" => "Rodri",
        "nacionalidade" => "Espanha",
        "categoria" => "Meio-Campo",
        "imagem" => "imagens/rodri.png",
        "descricao" => "Volante do Manchester City, peça-chave no controle do meio de campo e transições.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 65,
        "Pique" => 66
    ],
    "Finalização" => [
        "Posicionamento" => 76,
        "Finalização" => 74,
        "Força do Chute" => 92,
        "Chutes de Longe" => 89,
        "Voleios" => 71,
        "Pênaltis" => 62
    ],
    "Passe" => [
        "Visão" => 84,
        "Cruzamento" => 76,
        "Precisão de Falta" => 64,
        "Passe Curto" => 93,
        "Passe Longo" => 91,
        "Efeito" => 86
    ],
    "Drible" => [
        "Agilidade" => 66,
        "Equilíbrio" => 67,
        "Reações" => 93,
        "Controle de Bola" => 90,
        "Drible" => 84,
        "Compostura" => 94
    ],
    "Defesa" => [
        "Intercepções" => 84,
        "Cabeceio" => 81,
        "Consciência Defensiva" => 92,
        "Desarme em Pé" => 87,
        "Carrinho" => 82
    ],
    "Físico" => [
        "Impulsão" => 83,
        "Fôlego" => 91,
        "Força" => 83,
        "Agressividade" => 85
    ]
]
    ],
    [
        "id" => 6,
        "nome" => "Jude Bellingham",
        "nacionalidade" => "Inglaterra",
        "categoria" => "Meio-Campo",
        "imagem" => "imagens/bellingham.png",
        "descricao" => "Meia do Real Madrid, jovem promessa inglesa com grande visão de jogo e chegada ao ataque.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 81,
        "Pique" => 80
    ],
    "Finalização" => [
        "Posicionamento" => 91,
        "Finalização" => 90,
        "Força do Chute" => 85,
        "Chutes de Longe" => 86,
        "Voleios" => 77,
        "Pênaltis" => 74
    ],
    "Passe" => [
        "Visão" => 90,
        "Cruzamento" => 66,
        "Precisão de Falta" => 68,
        "Passe Curto" => 89,
        "Passe Longo" => 89,
        "Efeito" => 73
    ],
    "Drible" => [
        "Agilidade" => 82,
        "Equilíbrio" => 79,
        "Reações" => 91,
        "Controle de Bola" => 89,
        "Drible" => 89,
        "Compostura" => 87
    ],
    "Defesa" => [
        "Intercepções" => 82,
        "Cabeceio" => 75,
        "Consciência Defensiva" => 77,
        "Desarme em Pé" => 79,
        "Carrinho" => 77
    ],
    "Físico" => [
        "Impulsão" => 84,
        "Fôlego" => 93,
        "Força" => 77,
        "Agressividade" => 85
    ]
]
    ],
    [
        "id" => 7,
        "nome" => "Harry Kane",
        "nacionalidade" => "Inglaterra",
        "categoria" => "Atacante",
        "imagem" => "imagens/kane.png",
        "descricao" => "Camisa 9 clássico, referência na área, artilheiro da Seleção Inglesa e do Bayern de Munique.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 64,
        "Pique" => 66
    ],
    "Finalização" => [
        "Posicionamento" => 94,
        "Finalização" => 95,
        "Força do Chute" => 94,
        "Chutes de Longe" => 89,
        "Voleios" => 89,
        "Pênaltis" => 93
    ],
    "Passe" => [
        "Visão" => 86,
        "Cruzamento" => 80,
        "Precisão de Falta" => 69,
        "Passe Curto" => 86,
        "Passe Longo" => 88,
        "Efeito" => 82
    ],
    "Drible" => [
        "Agilidade" => 66,
        "Equilíbrio" => 73,
        "Reações" => 94,
        "Controle de Bola" => 87,
        "Drible" => 82,
        "Compostura" => 92
    ],
    "Defesa" => [
        "Intercepções" => 42,
        "Cabeceio" => 91,
        "Consciência Defensiva" => 46,
        "Desarme em Pé" => 46,
        "Carrinho" => 38
    ],
    "Físico" => [
        "Impulsão" => 87,
        "Fôlego" => 75,
        "Força" => 86,
        "Agressividade" => 80
    ]
]
    ],
    [
        "id" => 8,
        "nome" => "Courtois",
        "nacionalidade" => "Bélgica",
        "categoria" => "Goleiro",
        "imagem" => "imagens/courtois.png",
        "descricao" => "Goleiro do Real Madrid, conhecido por defesas milagrosas e excelente posicionamento.",
        "stats" => [
    "Goleiro" => [
        "Mergulho" => 85,
        "Manuseio" => 89,
        "Chute" => 76,
        "Reflexos" => 90,
        "Velocidade" => 46,
        "Posicionamento" => 88
    ],
    "Ritmo" => [
        "Aceleração" => 42,
        "Pique" => 52
    ],
    "Finalização" => [
        "Posicionamento" => 13,
        "Finalização" => 14,
        "Força do Chute" => 57,
        "Chutes de Longe" => 17,
        "Voleios" => 12,
        "Pênaltis" => 27
    ],
    "Passe" => [
        "Visão" => 44,
        "Cruzamento" => 14,
        "Precisão de Falta" => 20,
        "Passe Curto" => 33,
        "Passe Longo" => 35,
        "Efeito" => 19
    ],
    "Drible" => [
        "Agilidade" => 63,
        "Equilíbrio" => 45,
        "Reações" => 88,
        "Controle de Bola" => 23,
        "Drible" => 13,
        "Compostura" => 66
    ],
    "Defesa" => [
        "Intercepções" => 15,
        "Cabeceio" => 13,
        "Consciência Defensiva" => 20,
        "Desarme em Pé" => 18,
        "Carrinho" => 16
    ],
    "Físico" => [
        "Impulsão" => 68,
        "Fôlego" => 38,
        "Força" => 70,
        "Agressividade" => 23
    ]
]
    ],
    [
        "id" => 9,
        "nome" => "Lautaro Martínez",
        "nacionalidade" => "Argentina",
        "categoria" => "Atacante",
        "imagem" => "imagens/lautaro.png",
        "descricao" => "Atacante argentino da Inter de Milão, campeão do mundo e referência ofensiva da equipe.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 84,
        "Pique" => 80
    ],
    "Finalização" => [
        "Posicionamento" => 92,
        "Finalização" => 93,
        "Força do Chute" => 87,
        "Chutes de Longe" => 80,
        "Voleios" => 92,
        "Pênaltis" => 74
    ],
    "Passe" => [
        "Visão" => 79,
        "Cruzamento" => 68,
        "Precisão de Falta" => 65,
        "Passe Curto" => 79,
        "Passe Longo" => 73,
        "Efeito" => 80
    ],
    "Drible" => [
        "Agilidade" => 89,
        "Equilíbrio" => 92,
        "Reações" => 92,
        "Controle de Bola" => 89,
        "Drible" => 85,
        "Compostura" => 88
    ],
    "Defesa" => [
        "Intercepções" => 48,
        "Cabeceio" => 86,
        "Consciência Defensiva" => 55,
        "Desarme em Pé" => 51,
        "Carrinho" => 44
    ],
    "Físico" => [
        "Impulsão" => 93,
        "Fôlego" => 83,
        "Força" => 85,
        "Agressividade" => 87
    ]
]
    ],
    [
        "id" => 10,
        "nome" => "Van Dijk",
        "nacionalidade" => "Holanda",
        "categoria" => "Zagueiro",
        "imagem" => "imagens/vandijk.png",
        "descricao" => "Zagueiro holandês do Liverpool, conhecido por sua força física, liderança e imposição aérea.",
        "stats" => [
    "Ritmo" => [
        "Aceleração" => 66,
        "Pique" => 87
    ],
    "Finalização" => [
        "Posicionamento" => 47,
        "Finalização" => 52,
        "Força do Chute" => 81,
        "Chutes de Longe" => 64,
        "Voleios" => 45,
        "Pênaltis" => 62
    ],
    "Passe" => [
        "Visão" => 67,
        "Cruzamento" => 53,
        "Precisão de Falta" => 70,
        "Passe Curto" => 80,
        "Passe Longo" => 86,
        "Efeito" => 60
    ],
    "Drible" => [
        "Agilidade" => 54,
        "Equilíbrio" => 50,
        "Reações" => 88,
        "Controle de Bola" => 77,
        "Drible" => 70,
        "Compostura" => 90
    ],
    "Defesa" => [
        "Intercepções" => 88,
        "Cabeceio" => 87,
        "Consciência Defensiva" => 90,
        "Desarme em Pé" => 91,
        "Carrinho" => 86
    ],
    "Físico" => [
        "Impulsão" => 89,
        "Fôlego" => 72,
        "Força" => 93,
        "Agressividade" => 85
    ]
]
    ]
    
];

$cartasNovas = $_SESSION['cartas_novas'] ?? [];

$cartas = array_merge($cartasFixas, $cartasNovas);
?>