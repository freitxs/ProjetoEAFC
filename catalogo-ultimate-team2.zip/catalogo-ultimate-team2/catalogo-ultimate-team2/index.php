<?php
include 'includes/cabecalho.php';
include 'dados/cartas.php';
include 'funcoes.php';

// Junta as cartas fixas com as novas da sessão, se existirem
$cartasCompletas = $cartas;
if (isset($_SESSION['cartas_novas'])) {
    $cartasCompletas = array_merge($cartas, $_SESSION['cartas_novas']);
}

// Captura os filtros
$categoria = $_GET['categoria'] ?? '';
$nacionalidade = $_GET['nacionalidade'] ?? '';
?>

<!-- 🔍 Formulário de Filtro -->
<form method="get" class="filtro-form">
    <label>Categoria:</label>
    <input type="text" name="categoria" placeholder="Atacante, Meio-Campo..." value="<?= htmlspecialchars($categoria) ?>">

    <label>Nacionalidade:</label>
    <input type="text" name="nacionalidade" placeholder="Brasil, Argentina..." value="<?= htmlspecialchars($nacionalidade) ?>">

    <button type="submit" class="botao">Filtrar</button>
    <a href="index.php" class="botao limpar">Limpar Filtros</a>

</form>

<!-- 📦 Cartas filtradas -->
<div class="container-cartas">
<?php
// Aplica os filtros nas cartas completas
$filtradas = array_filter($cartasCompletas, function ($carta) use ($categoria, $nacionalidade) {
    $okCategoria = !$categoria || stripos($carta['categoria'], $categoria) !== false;
    $okNacionalidade = !$nacionalidade || stripos($carta['nacionalidade'] ?? '', $nacionalidade) !== false;
    return $okCategoria && $okNacionalidade;
});

if (!empty($filtradas)) {
    foreach ($filtradas as $carta) {
        exibirCarta($carta);
    }
} else {
    echo "<p style='padding: 20px;'>Nenhuma carta encontrada para os filtros aplicados.</p>";
}
?>
</div>

<?php include 'includes/rodape.php'; ?>
