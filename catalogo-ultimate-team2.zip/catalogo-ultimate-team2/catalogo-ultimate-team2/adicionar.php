
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Carta</title>
</head>
<body>
    <h2>Adicionar Nova Carta</h2>
    <form action="salvar.php" method="POST" enctype="multipart/form-data">
        <label for="nome">Nome:</label><br>
        <input type="text" name="nome" id="nome" required><br><br>

        <label for="nacionalidade">Nacionalidade:</label><br>
        <input type="text" name="nacionalidade" id="nacionalidade" required><br><br>

        <label for="categoria">Categoria:</label><br>
        <input type="text" name="categoria" id="categoria" required><br><br>

        <label for="descricao">Descrição:</label><br>
        <textarea name="descricao" id="descricao" required></textarea><br><br>

        <label for="imagem">Imagem (PNG):</label><br>
        <input type="file" name="imagem" id="imagem" accept="image/png" required><br><br>

        <button type="submit">Salvar Carta</button>
    </form>
</body>
</html>
