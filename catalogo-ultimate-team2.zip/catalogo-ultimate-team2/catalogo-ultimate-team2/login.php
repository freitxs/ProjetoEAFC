<?php
session_start();
$erro = '';

$usuarioFixo = 'admin';
$senhaHash = password_hash('1234', PASSWORD_DEFAULT);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    if ($usuario === $usuarioFixo && password_verify($senha, $senhaHash)) {
        $_SESSION['logado'] = true;
        header('Location: protegido.php');
        exit;
    } else {
        $erro = "Usuário ou senha inválidos.";
    }
}
?>

<?php include 'includes/cabecalho.php'; ?>

<h2>Login</h2>
<form method="post">
    <label>Usuário:</label><br>
    <input type="text" name="usuario"><br>
    <label>Senha:</label><br>
    <input type="password" name="senha"><br><br>
    <button type="submit">Entrar</button>
</form>
<p style="color:red;"><?= $erro ?></p>

<?php include 'includes/rodape.php'; ?>