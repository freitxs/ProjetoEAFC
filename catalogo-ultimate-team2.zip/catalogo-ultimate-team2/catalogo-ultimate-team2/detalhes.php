<?php
include 'includes/cabecalho.php';
include 'dados/cartas.php';

// Junta cartas fixas e novas
$cartasCompletas = $cartas;
if (isset($_SESSION['cartas_novas'])) {
    $cartasCompletas = array_merge($cartas, $_SESSION['cartas_novas']);
}

$id = $_GET['id'] ?? null;
$carta = null;

// Busca a carta com o ID
foreach ($cartasCompletas as $c) {
    if ($c['id'] == $id) {
        $carta = $c;
        break;
    }
}

if (!$carta) {
    echo "<p>Carta não encontrada.</p>";
    include 'includes/rodape.php';
    exit;
}
?>

<div class="carta-detalhes">
    <h2><?= $carta['nome'] ?></h2>
    <img src="<?= $carta['imagem'] ?>" alt="<?= $carta['nome'] ?>" style="max-width:200px;">
    <p><strong>Categoria:</strong> <?= $carta['categoria'] ?></p>
    <p><strong>Nacionalidade:</strong> <?= isset($carta['nacionalidade']) ? $carta['nacionalidade'] : 'Nacionalidade não informada' ?></p>
    <p><?= $carta['descricao'] ?></p>

    <h3>Estatísticas</h3>
    <?php if (isset($carta['stats'])): ?>
        <div class="tabela-stats">
            <?php foreach ($carta['stats'] as $grupo => $atributos): ?>
                <h4><?= $grupo ?></h4>
                <table>
                    <?php foreach ($atributos as $nome => $valor): ?>
                        <tr>
                            <td><?= $nome ?></td>
                            <td><?= $valor ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Sem estatísticas cadastradas.</p>
    <?php endif; ?>
</div>

<a href="index.php">← Voltar</a>

<?php include 'includes/rodape.php'; ?>
