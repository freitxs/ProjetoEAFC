<?php include 'includes/cabecalho.php'; ?>

<?php
// Verifica se está logado
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header('Location: index.php');
    exit;
}

// Inicia a lista de cartas novas, se não existir
if (!isset($_SESSION['cartas_novas'])) {
    $_SESSION['cartas_novas'] = [];
}

// Se o formulário for enviado, salva a nova carta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $novaCarta = [
        "id" => time(),
        "nome" => $_POST['nome'],
        "categoria" => $_POST['categoria'],
        "imagem" => $_POST['imagem'],
        "descricao" => $_POST['descricao']
    ];

    $_SESSION['cartas_novas'][] = $novaCarta;
    header('Location: index.php');
    exit;
}
?>

<!-- Estilo do formulário -->
<style>
    .form-container {
        max-width: 500px;
        margin: 40px auto;
        background-color: #f9f9f9;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
        font-family: Arial, sans-serif;
    }

    .form-container h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #333;
    }

    .form-container label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #555;
    }

    .form-container input,
    .form-container textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
        font-size: 14px;
    }

    .form-container textarea {
        resize: vertical;
        min-height: 80px;
    }

    .form-container button {
        width: 100%;
        padding: 12px;
        background-color: #007BFF;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .form-container button:hover {
        background-color: #0056b3;
    }

    .form-container .voltar {
        display: block;
        text-align: center;
        margin-top: 15px;
        color: #007BFF;
        text-decoration: none;
    }

    .form-container .voltar:hover {
        text-decoration: underline;
    }
</style>

<!-- Formulário estilizado -->
<div class="form-container">
    <h2>Cadastrar Nova Carta</h2>
    <form method="post">
        <label>Nome do Jogador:</label>
        <input type="text" name="nome" required>

        <label>Categoria:</label>
        <input type="text" name="categoria" required>

        <label>URL da Imagem:</label>
        <input type="text" name="imagem" required>

        <label>Descrição:</label>
        <textarea name="descricao" required></textarea>

        <button type="submit">Cadastrar</button>
    </form>

    <a class="voltar" href="index.php">← Voltar para o catálogo</a>
</div>

<?php include 'includes/rodape.php'; ?>
