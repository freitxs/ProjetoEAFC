<?php
function exibirCarta($carta) {
    echo "<div class='carta'>";
    echo "<img src='{$carta['imagem']}' alt='{$carta['nome']}'width='200px'>";
    echo "<h2>{$carta['nome']}</h2>";
    echo "<p><strong>Nacionalidade:</strong> " .
    (isset($carta['nacionalidade']) ? $carta['nacionalidade'] : 'Nacionalidade não informada') .
    "</p>";
    echo "<p><strong>Categoria:</strong> {$carta['categoria']}</p>";
    echo "<p>{$carta['descricao']}</p>";
    echo "<a href='detalhes.php?id={$carta['id']}'>Ver mais</a>";
    echo "</div>";
}
function filtrarCartas($cartas, $categoria) {
    return array_filter($cartas, function($carta) use ($categoria) {
        return strtolower($carta['categoria']) === strtolower($categoria);
    });
}
?>