<?php
include 'includes/cabecalho.php';
include 'dados/cartas.php';
include 'funcoes.php';

$categoria = $_GET['categoria'] ?? '';

echo "<form method='get'>
    <label>Categoria:</label>
    <input type='text' name='categoria' placeholder='Atacante, Meio-Campo...'>
    <button type='submit'>Filtrar</button>
</form>";

if ($categoria) {
    $filtradas = filtrarCartas($cartas, $categoria);
    if (empty($filtradas)) {
        echo "<p>Nenhuma carta encontrada para '$categoria'.</p>";
    } else {
        foreach ($filtradas as $carta) {
            exibirCarta($carta);
        }
    }
}

include 'includes/rodape.php';
?>